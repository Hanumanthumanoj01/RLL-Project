export class Admin {}
